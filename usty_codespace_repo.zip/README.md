# USTYToken

This Codespace is preconfigured for developing the USTYToken smart contract using Hardhat and OpenZeppelin.

## Quick Start

1. Open this repo in GitHub Codespaces
2. Open a terminal and run:

```bash
npx hardhat compile
npx hardhat run scripts/deploy-usty.js --network sepolia
```

Be sure to update the fee collector address before deploying.
